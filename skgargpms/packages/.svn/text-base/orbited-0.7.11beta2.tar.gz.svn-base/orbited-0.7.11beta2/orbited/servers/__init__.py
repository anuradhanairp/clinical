import echo, lineecho, rude, announce, monitor

test_servers = {
    'echo': echo.Echo,
    'lineecho': lineecho.LineEcho,
    'rude': rude.Rude,
    'announce': announce.Announce,
    'monitor': monitor.Monitor
}